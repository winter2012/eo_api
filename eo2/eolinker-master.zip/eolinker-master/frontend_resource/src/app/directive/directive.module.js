(function() {
	'use strict';
	/* 指令模块 */
	angular.module('eolinker.directive',['ui.bootstrap.pagination','ui.bootstrap.modal','ui.bootstrap.popover'])
     
})();


