(function() {
	'use strict';
	/* 服务模块 */
	angular.module('eolinker.service',[])
})();