(function() {
	'use strict';
	/* 过滤器模块 */
	angular.module('eolinker.filter',[])
})();


