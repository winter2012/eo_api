(function () { 
 return angular.module("eolinker")
.constant("serverUrl", "/eolinker_os/server/index.php")
.constant("isDebug", false)
.constant("assetUrl", "")
.constant("COOKIE_CONFIG", {"path":"/","domain":".eolinker.com"});

})();
