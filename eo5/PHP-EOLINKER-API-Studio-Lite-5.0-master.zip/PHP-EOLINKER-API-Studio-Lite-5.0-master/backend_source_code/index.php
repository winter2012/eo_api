<?php
/**
 * @name eolinker open source，EOLINKER OPEN SOURCE
 * @link https://www.eolinker.com
 * @package eolinker
 * @author www.eolinker.com EOLINKER co,.LTD 2015-2018

 * ELOINKER, industry-leading Api management and test platform provides you with the most professional and convenient online interface management, testing, maintenance and various performance testing solutions to help you develop efficiently and securely.
 * If you have any problems during the process of use
 *
 * 
 * Note! The eolinker open source version follows the GPL V3 open source protocol and is only available for users to download and try.  
 * It is forbidden to "all publicly available for commercial use" or "a second version developed on the basis of the open source version 
 * of EOLINKER" is circulated on the Internet.
 * Attention! Once discovered, we will immediately activate legal procedures for rights protection.
 * Thank you again for your use, I hope we can jointly maintain the domestic Internet open source civilization and normal business order.
 *
 */

//define framework
defined('PATH_FW') or define('PATH_FW', './RTP');

//require path directory
require PATH_FW . DIRECTORY_SEPARATOR . 'rtp.inc.php';
?>
