(function() {
    'use strict';
   	/**
     * @Author   广州银云信息科技有限公司 eolinker
     * @function [过滤器模块] [Filter module]
     * @version  3.0.2
     */
    angular.module('eolinker.filter', [])
})();
