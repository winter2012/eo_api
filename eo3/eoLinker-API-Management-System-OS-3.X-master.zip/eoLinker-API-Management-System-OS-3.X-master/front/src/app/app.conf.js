(function () { 
 return angular.module("eolinker")
.constant("serverUrl", "./server/index.php")
.constant("isDebug", false)
.constant("assetUrl", "")
.constant("COOKIE_CONFIG", {"path":"/","domain":".eolinker.com"});

})();
