(function() {
    'use strict';
    /**
     * @Author   广州银云信息科技有限公司 eolinker	
     * @function [常量模块] [Constant module]
     * @version  3.0.2
     */
    angular.module('eolinker.constant', [])
})();