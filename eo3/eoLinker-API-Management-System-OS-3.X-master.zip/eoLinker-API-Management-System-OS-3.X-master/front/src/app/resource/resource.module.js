(function() {
    'use strict';
    /**
     * @Author   广州银云信息科技有限公司 eolinker
     * @function [定义resource模块js] [Define the resource module js]
     * @version  3.0.2
     */
    angular.module('eolinker.resource', [])

})();
